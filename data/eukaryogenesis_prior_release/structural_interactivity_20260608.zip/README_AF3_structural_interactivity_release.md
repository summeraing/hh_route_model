# AF3 Structural-Interactivity Release

This folder contains the AlphaFold 3 structural-interactivity outputs used for the manuscript figure on local energetic-interface feasibility and gate calibration.

## Contents

- `representative_models_cif/`: representative AF3 model CIF files for 19 protein-pair screens.
- `confidence_json/`: AF3 summary confidence outputs for the same 19 pair models.
- `ranking_scores/`: per-pair ranking score CSV files, renamed by pair identifier.
- `interface_metric_tables/`: integrated manuscript-facing tables, including AF3 confidence gates, interface metrics, negative-control summaries and Source Data workbooks.

## Manuscript Use

These files support the AF3 structural-interactivity layer in Fig. 4 and the accompanying Source Data. The screen is used as a gate-calibrated structural-feasibility check, not as a direct reconstruction of ancestral binding interfaces.

## Interpretation Boundary

AF3 confidence scores, buried surface area and contact counts are interpreted together. Apparent contact area is not treated as evidence of compatibility unless the model passes the specified interface-confidence gate.

## Not Included

This release does not include proprietary AF3 model parameters or a one-command reconstruction of all public raw evidence sources. It is intended to provide the model outputs and processed tables needed to inspect the manuscript's structural-interface claims.
